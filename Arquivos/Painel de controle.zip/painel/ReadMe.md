project moved to https://github.com/DarkSecDevelopers/LitePhish
<h1> Gray Fish v2020.04</h1>
<a href=https://discord.gg/Hu5XPGMTuk><img src=https://img.shields.io/discord/787203724975931413?label=discord /></a>

<p>Gray Fish contains phishing pages. <b>Before using it, make sure to read guide to avoid any problem.</b></p>
<center><img src="https://i.ibb.co/PmH73X4/index.png" style="max-width:100%;align:middle;border:0;" alt="Gray Fish"></center>
<h2> Features</h2>
<ul><li>Almost, all Templates are under 20KBs that helps in loading webpages fast.</li>
<li>Images are encoded in base64 to avoid external + internal linking.</li>
<li>Codes are highly compressed. Extra codes have been removed.</li>
<li>Login form can't be bypass until all inputs have been filled by a victim.</li>
<li>Link with custom preview(image + title + description) when shared on any website.</li>
<li>Admin login panel has been created for absolute dummies.</li></ul><br>
<img src="https://i.ibb.co/qmwBf5k/images.png">
<h2> Usage</h2>
<pre><code>
git clone https://github.com/graysuit/grayfish.git
</code></pre>
<br><p><ol><li>Upload all files to any web hosting you like</li>
<li>Enter your sitename and fill username & password(Default user & pass is <b>fish</b>)</li>
<li>Select any phishing link</li>
<li>Shorten link if you want</li>
<li>Send the link to your victim</li>
<li><b>Note:</b> Username/Password will be displayed in admin panel</li></ol></p><br>
<center><img src="https://img.wonderhowto.com/img/15/72/63704809025462/0/phish-for-social-media-other-accounts-with-grayfish.w1456.jpg" style="width:100%;align:middle;border:0;" alt="Gray Fish"></center>
<h2> Available phishing sites/templates</h2>
<details>
<summary>Click me to view sites</summary>
<br><ol>
<li>Dropbox</li>
<li>Facebook_desktop_homepage</li>
<li>Facebook_desktop_static</li>
<li>Facebook_mobile + 2FA</li>
<li>Facebook_mobile_fake_security</li>
<li>Github</li>
<li>Garena Free Fire</li>
<li>Instagram</li>
<li>Linkedin</li>
<li>Microsoft</li>
<li>Netflix</li>
<li>Protonmail</li>
<li>Snapchat</li>
<li>Tumblr</li>
<li>Messenger</li>
<li>Twitter_desktop</li>
<li>Wordpress</li>
<li>Yahoo</li></ol></details>
<h2> Gray Fish Admin Panel Default user & pass:</h2>
<ul><li>Username = <b>fish</b></li>
<li>Password = <b>fish</b></li></ul>
<h2> Tutorials:</h2>
<ul><li><a href="https://www.facebook.com/ncybersec/videos/430378990922089/">Facebook Video</a></li>
<li><a href="https://null-byte.wonderhowto.com/forum/phish-for-social-media-other-accounts-with-grayfish-0206861/">Null Byte Article</a></li>
<li><a href="https://esgeeks.com/gray-fish-paginas-phishing-indetectables/">Spanish Article + video <b>Páginas de Phishing Totalmente Indetectables</b></a></li>
<li>English Article<a href="https://freelearningtech.in/how-hackers-create-undetectable-phishing-pages/">How hackers create undetectable phishing pages?</b></a></li>
<h2> <li><a href="https://github.com/graysuit/grayfish/blob/master/readme_extra.md">Extra things</a></li></ul></h2> 
<h2> Contact me :</h2>
<ul>
<li>Email: <b><a href="mailto:hackrefisher@gmail.com">hackrefisher@gmail.com</a></b></li>
<li>Website: <a href="https://tiplava.blogspot.com/"><b>tiplava</b></a></li>
<li>Discord: <a href="https://discord.gg/Hu5XPGMTuk"><b>Fishes</b></a></li>
</ul>
<h1>I Love ALLAH + Holy Prophet + Islam and Pakistan.</h1>
