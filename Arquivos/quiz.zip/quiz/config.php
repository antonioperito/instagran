<?php
 class Config 
{
   public static $dbUsername = 'admin';
   public static $dbPassword  = '$2y$10$cW16sJt4Kp9p9hZSpOrTmeRTO/1oxXwTKBeI565R0QtR5AELWCSS.';
}

?>