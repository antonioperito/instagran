<?php
    header('Status: 301 Moved permanently', false, 301);
    header('Location:Quiz.php');
    exit();